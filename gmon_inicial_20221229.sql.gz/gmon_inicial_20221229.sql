--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO postgres;

--
-- Name: auditoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auditoria (
    id bigint NOT NULL,
    descricao character varying,
    usuario character varying,
    processo character varying,
    registro_id integer,
    campos character varying,
    alteracoes character varying,
    inicio timestamp without time zone,
    termino timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.auditoria OWNER TO postgres;

--
-- Name: auditoria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auditoria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auditoria_id_seq OWNER TO postgres;

--
-- Name: auditoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auditoria_id_seq OWNED BY public.auditoria.id;


--
-- Name: campos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campos (
    id bigint NOT NULL,
    nome character varying,
    campo character varying,
    campo_id character varying,
    atributo_tag character varying,
    status boolean,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.campos OWNER TO postgres;

--
-- Name: classes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.classes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.classes_id_seq OWNER TO postgres;

--
-- Name: classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.classes_id_seq OWNED BY public.campos.id;


--
-- Name: grupos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grupos (
    id bigint NOT NULL,
    identificador character varying,
    nome character varying,
    modulo character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.grupos OWNER TO postgres;

--
-- Name: grupos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grupos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grupos_id_seq OWNER TO postgres;

--
-- Name: grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grupos_id_seq OWNED BY public.grupos.id;


--
-- Name: grupos_usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grupos_usuarios (
    id bigint NOT NULL,
    usuario_id integer,
    grupo_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.grupos_usuarios OWNER TO postgres;

--
-- Name: grupos_usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grupos_usuarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grupos_usuarios_id_seq OWNER TO postgres;

--
-- Name: grupos_usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grupos_usuarios_id_seq OWNED BY public.grupos_usuarios.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id bigint NOT NULL,
    nome character varying,
    campo_id integer,
    valor_tag character varying,
    status boolean,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_id_seq OWNER TO postgres;

--
-- Name: items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.items_id_seq OWNED BY public.items.id;


--
-- Name: monitors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monitors (
    id bigint NOT NULL,
    monitoracao_id integer,
    titulo character varying,
    dashboard character varying,
    impacto_it character varying,
    impacto_negocio character varying,
    integracao_jira boolean,
    taxonomia boolean,
    tag_ccbp boolean,
    prioridade character varying,
    url character varying,
    status boolean,
    data_ativacao timestamp(6) without time zone,
    data_desativacao timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.monitors OWNER TO postgres;

--
-- Name: monitors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.monitors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.monitors_id_seq OWNER TO postgres;

--
-- Name: monitors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.monitors_id_seq OWNED BY public.monitors.id;


--
-- Name: monitors_items_relations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monitors_items_relations (
    id bigint NOT NULL,
    mon_id integer,
    item_id integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.monitors_items_relations OWNER TO postgres;

--
-- Name: monitors_items_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.monitors_items_relations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.monitors_items_relations_id_seq OWNER TO postgres;

--
-- Name: monitors_items_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.monitors_items_relations_id_seq OWNED BY public.monitors_items_relations.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id bigint NOT NULL,
    username character varying,
    password_digest character varying,
    nome character varying,
    status boolean,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: auditoria id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditoria ALTER COLUMN id SET DEFAULT nextval('public.auditoria_id_seq'::regclass);


--
-- Name: campos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campos ALTER COLUMN id SET DEFAULT nextval('public.classes_id_seq'::regclass);


--
-- Name: grupos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grupos ALTER COLUMN id SET DEFAULT nextval('public.grupos_id_seq'::regclass);


--
-- Name: grupos_usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grupos_usuarios ALTER COLUMN id SET DEFAULT nextval('public.grupos_usuarios_id_seq'::regclass);


--
-- Name: items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items ALTER COLUMN id SET DEFAULT nextval('public.items_id_seq'::regclass);


--
-- Name: monitors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitors ALTER COLUMN id SET DEFAULT nextval('public.monitors_id_seq'::regclass);


--
-- Name: monitors_items_relations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitors_items_relations ALTER COLUMN id SET DEFAULT nextval('public.monitors_items_relations_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	default_env	2022-10-17 14:39:03.37336	2022-10-17 14:39:03.37336
\.


--
-- Data for Name: auditoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auditoria (id, descricao, usuario, processo, registro_id, campos, alteracoes, inicio, termino, created_at, updated_at) FROM stdin;
276	LOGIN SUCESSO IP: 127.0.0.1	carol.figueiredo	gmon	\N	\N	\N	\N	\N	2022-12-29 11:45:29.694519	2022-12-29 11:45:29.694519
277	127.0.0.1 - usuário jefferson.brunheira criado	carol.figueiredo	gmon - administracao	\N	\N	\N	\N	\N	2022-12-29 11:46:10.11005	2022-12-29 11:46:10.11005
\.


--
-- Data for Name: campos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.campos (id, nome, campo, campo_id, atributo_tag, status, created_at, updated_at) FROM stdin;
1	DRU	\N	\N	ccbp-dru	t	2022-12-21 13:18:40.263775	2022-12-27 16:38:04.163351
3	Produto	\N	\N	ccbp-produto	t	2022-12-21 13:18:53.393864	2022-12-27 16:38:15.578657
4	Sintoma	\N	\N	ccbp-sintoma	\N	2022-12-27 16:40:42.759005	2022-12-27 16:40:42.759005
2	Jornada	\N	\N	ccbp-jornada	t	2022-12-21 13:18:47.202037	2022-12-27 16:45:12.399869
7	Impacto	\N	\N	ccbp-impacto	\N	2022-12-27 16:48:08.805681	2022-12-27 16:48:49.992612
\.


--
-- Data for Name: grupos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grupos (id, identificador, nome, modulo, created_at, updated_at) FROM stdin;
1	gmon_admin	Admin GMON	gmon	2022-10-17 16:33:06.639826	2022-10-17 16:33:06.639826
2	gmon_usuario	Usuário GMON	gmon	2022-10-17 16:33:10.949719	2022-10-17 16:33:10.949719
\.


--
-- Data for Name: grupos_usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grupos_usuarios (id, usuario_id, grupo_id, created_at, updated_at) FROM stdin;
1	1	1	2022-10-17 16:35:02.621387	2022-10-17 16:35:02.621387
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id, nome, campo_id, valor_tag, status, created_at, updated_at) FROM stdin;
1	BaaS	1	baas	t	2022-12-22 13:40:38.091969	2022-12-27 21:04:45.191606
2	Banking	1	banking	t	2022-12-22 13:40:46.217999	2022-12-26 11:43:16.462536
3	Conta Corrente	2	conta-corrente	t	2022-12-22 13:40:57.864951	2022-12-26 12:38:55.667487
4	PIX	3	pix	t	2022-12-22 13:41:05.488928	2022-12-26 12:38:55.675487
5	Login	3	login	t	2022-12-22 13:41:10.407799	2022-12-26 12:38:55.683888
\.


--
-- Data for Name: monitors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monitors (id, monitoracao_id, titulo, dashboard, impacto_it, impacto_negocio, integracao_jira, taxonomia, tag_ccbp, prioridade, url, status, data_ativacao, data_desativacao, created_at, updated_at) FROM stdin;
1	0	Monitor 1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2022-12-22 13:45:26.23097	2022-12-22 13:45:26.23097
2	0	Monitor 2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2022-12-22 13:45:34.204331	2022-12-22 13:45:34.204331
3	0	Monitor Infra 1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2022-12-22 13:45:46.835367	2022-12-22 13:45:46.835367
\.


--
-- Data for Name: monitors_items_relations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monitors_items_relations (id, mon_id, item_id, created_at, updated_at) FROM stdin;
1	1	1	2022-12-22 14:10:39.020177	2022-12-22 14:10:39.020177
2	1	3	2022-12-22 14:10:41.870141	2022-12-22 14:10:41.870141
3	1	5	2022-12-22 14:10:45.109842	2022-12-22 14:10:45.109842
4	2	2	2022-12-22 14:10:54.876925	2022-12-22 14:10:54.876925
5	2	3	2022-12-22 14:10:58.989778	2022-12-22 14:10:58.989778
6	2	5	2022-12-22 14:11:04.054104	2022-12-22 14:11:04.054104
7	3	2	2022-12-22 14:11:08.97428	2022-12-22 14:11:08.97428
8	3	3	2022-12-22 14:11:11.43945	2022-12-22 14:11:11.43945
9	3	4	2022-12-22 14:11:13.102748	2022-12-22 14:11:13.102748
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_migrations (version) FROM stdin;
20221017143652
20221017144129
20221017144323
20221017144539
20221019144026
20221019144053
20221019144118
20221019144140
20221019144200
20221019144220
20221019144239
20221104125339
20221120120055
20221120120256
20221221122847
20221221124629
20221221124741
20221221130327
20221222122859
20221222123103
20221222124342
20221222124736
20221222131739
20221226195521
20221226195928
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id, username, password_digest, nome, status, created_at, updated_at) FROM stdin;
1	carol.figueiredo	$2a$12$xeMQOBTGrhigOHxfhsr3RuLRQKNymVz1ueQxYh3uBIO6Ohqq1yobS	Carol Figueiredo	t	2022-10-17 16:30:55.391953	2022-12-15 19:02:10.626418
4	jefferson.brunheira	$2a$12$c2LQlS3gtKXLsH82yoA64ukQ.7adUoI9LXqaWxu3rU1seq5TZtZl6	Jefferson Brunheira	t	2022-12-29 11:46:10.071153	2022-12-29 11:46:10.071153
\.


--
-- Name: auditoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auditoria_id_seq', 277, true);


--
-- Name: classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.classes_id_seq', 7, true);


--
-- Name: grupos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grupos_id_seq', 2, true);


--
-- Name: grupos_usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grupos_usuarios_id_seq', 1, true);


--
-- Name: items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.items_id_seq', 43, true);


--
-- Name: monitors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.monitors_id_seq', 3, true);


--
-- Name: monitors_items_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.monitors_items_relations_id_seq', 9, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 4, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: auditoria auditoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditoria
    ADD CONSTRAINT auditoria_pkey PRIMARY KEY (id);


--
-- Name: campos classes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campos
    ADD CONSTRAINT classes_pkey PRIMARY KEY (id);


--
-- Name: grupos grupos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grupos
    ADD CONSTRAINT grupos_pkey PRIMARY KEY (id);


--
-- Name: grupos_usuarios grupos_usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grupos_usuarios
    ADD CONSTRAINT grupos_usuarios_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: monitors_items_relations monitors_items_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitors_items_relations
    ADD CONSTRAINT monitors_items_relations_pkey PRIMARY KEY (id);


--
-- Name: monitors monitors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

